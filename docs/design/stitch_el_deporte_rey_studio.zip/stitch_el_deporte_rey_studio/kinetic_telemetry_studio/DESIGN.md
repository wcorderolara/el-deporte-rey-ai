---
name: Kinetic Telemetry Studio
colors:
  surface: '#14121d'
  surface-dim: '#14121d'
  surface-bright: '#3a3744'
  surface-container-lowest: '#0f0d18'
  surface-container-low: '#1c1a26'
  surface-container: '#201e2a'
  surface-container-high: '#2b2835'
  surface-container-highest: '#363340'
  on-surface: '#e6e0f0'
  on-surface-variant: '#c2c6d7'
  inverse-surface: '#e6e0f0'
  inverse-on-surface: '#312f3b'
  outline: '#8c90a0'
  outline-variant: '#424655'
  surface-tint: '#b0c6ff'
  primary: '#b0c6ff'
  on-primary: '#002c6f'
  primary-container: '#568dff'
  on-primary-container: '#002662'
  inverse-primary: '#0058cc'
  secondary: '#d3bbff'
  on-secondary: '#3f008e'
  secondary-container: '#5721af'
  on-secondary-container: '#c4a6ff'
  tertiary: '#f5be45'
  on-tertiary: '#402d00'
  tertiary-container: '#b98908'
  on-tertiary-container: '#382700'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d9e2ff'
  primary-fixed-dim: '#b0c6ff'
  on-primary-fixed: '#001945'
  on-primary-fixed-variant: '#00419c'
  secondary-fixed: '#eaddff'
  secondary-fixed-dim: '#d3bbff'
  on-secondary-fixed: '#25005a'
  on-secondary-fixed-variant: '#5721af'
  tertiary-fixed: '#ffdea2'
  tertiary-fixed-dim: '#f5be45'
  on-tertiary-fixed: '#261900'
  on-tertiary-fixed-variant: '#5c4200'
  background: '#14121d'
  on-background: '#e6e0f0'
  surface-variant: '#363340'
typography:
  display-hero:
    fontFamily: Anybody
    fontSize: 64px
    fontWeight: '900'
    lineHeight: 68px
    letterSpacing: -0.04em
  display-hero-mobile:
    fontFamily: Anybody
    fontSize: 36px
    fontWeight: '900'
    lineHeight: 40px
    letterSpacing: -0.03em
  headline-xl:
    fontFamily: Anybody
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Anybody
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Anybody
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Anybody
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 26px
    letterSpacing: -0.01em
  stat-counter:
    fontFamily: Anybody
    fontSize: 48px
    fontWeight: '900'
    lineHeight: 48px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.12em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an aggressive, high-velocity sports broadcast aesthetic engineered specifically for high-tempo digital sports newsrooms, analytics hubs, and visual creators. Merging the raw data density of modern Formula and football telemetry dashboards with high-end sports media production, the interface evokes hyper-focus, tactical precision, and real-time urgency. 

The aesthetic is anchored in an uncompromising dark substrate, razor-sharp technical boundaries, zero-radius geometry, and electric broadcast accents. It eliminates decorative soft-edges in favor of structural grids, high-contrast monospace metadata readouts, dynamic status tickers, and kinetic visual framing. The emotional tone is authoritative, athletic, and surgically precise—designed to empower sports editors, analysts, and content creators to operate at matchday velocity.

## Colors

The palette draws its energy directly from matchday floodlights cutting through pitch darkness. 

- **Primary (`#2575FC` - Kinetic Matchday Blue):** The operational pulse. Used for live state telemetry, dynamic generation progress bars, tactical canvas frames, and precision cursor targets.
- **Secondary (`#7040C8` - Electric Violet):** Evokes the broadcast suite and deep stadium shadows. Forms ambient gradients across headers, AI compute overlays, and secondary toolbars.
- **Tertiary (`#F4BD44` - Championship Gold):** Reserved as a strategic focal point. Strictly utilized for definitive call-to-actions (`Crear publicación`, `Exportar`), trophy indices, game-breaking stats, and critical match highlights.
- **Neutrals & Surfaces:** Built on a layered obsidian hierarchy starting at the baseline `#0D0B16` (Pitch Black canvas), stepping upward to `#151124` (Telemetry panel background), `#1F1935` (Active sports card substrate), and `#2A2246` (Modal / Inspector floating surfaces).
- **Linework & Contrast:** Strict hairline dividers use `#312852`. Typography adheres strictly to high legibility: `#FFFFFF` for primary statistics and headlines, `#A5A1B8` for technical annotations and body copy, and `#69647C` for contextual telemetry timestamps and unit labels.

## Typography

The typographic hierarchy combines the raw athletic power and condensed velocity of **Anybody** with the geometric precision of **Space Grotesk**. 

- **Anybody (Display, Headlines, & Numerical Telemetry):** Serves as the broadcast voice. With aggressive condensed proportions, extreme variable weights, and tight letter-spacing, it conveys immediate urgency on headlines, score readouts, and player statistics. Numerical scores must always leverage tabular numerals (`tnum`) to eliminate layout jitter during live score feeds.
- **Space Grotesk (Body, Control Systems, & Metadata):** Acts as the technical counterpart. Its distinctive monospace-inspired curves and mechanical proportions ensure that AI prompts, tactical parameters, tactical timestamps, and analytical copy remain legible at rapid scan rates.
- **Casing Rules:** Structural meta-labels, telemetry units (e.g., `XG`, `MIN 90+4'`, `TIRO A PUERTA`), and status flags must always be styled in uppercase with expanded letter-spacing (`label-caps`).

## Layout & Spacing

The layout is built around a dense, high-efficiency broadcast desk model using a technical fluid grid. The interface prioritizes screen real estate for direct canvas manipulation and rapid content composition.

- **Workspace Topology:** Desktop layouts use a rigid 3-zone horizontal division: a locked 72px utility rail on the far left, a dynamic 320px telemetry and prompt sidebar, a fluid central canvas area, and a 360px collapsible inspector panel on the right.
- **Vertical Rhythm:** Rooted in a strict 4px/8px incremental base. Gaps between technical metric meters leverage tight increments (`space-xs` to `space-sm`), while studio layout groupings and canvas containers enforce wider visual separations (`space-lg` to `space-xl`).
- **Responsive Adaptations:**
  - *Desktop (> 1200px):* Full 12-column sub-grid within central canvas space; multi-panel simultaneous editing.
  - *Tablet (768px - 1199px):* Utility rail collapses to a horizontal icon strip; the inspector tucks into a sliding drawer overlay.
  - *Mobile (< 768px):* Single-column flow with pinned bottom action deck for tactical quick-actions and sports card generation previews.

## Elevation & Depth

This design system avoids diffused, soft atmospheric blurs, instead employing crisp technical planar layering and calibrated laser-sharp glows that simulate LED stadium signage and high-end broadcast monitors.

- **Planar Tiering:** Depth is conveyed through hard surface contrast rather than drop shadows. Base workspaces rest on `#0D0B16`, tool panels sit elevated at `#151124`, card surfaces advance to `#1F1935`, and floating popovers reach `#2A2246`.
- **Hairline Bounding:** Every container, panel, and floating palette is delineated by a 1px solid border in `#312852`. 
- **Kinetic Accent Glows:** When elements enter focus or live generation mode, the hairline border shifts to `#2575FC` or `#F4BD44` accompanied by a controlled, directional perimeter glow (`0 0 12px rgba(37, 117, 252, 0.45)` or `0 0 16px rgba(244, 189, 68, 0.35)`).
- **Z-Index Layering:**
  - `Level 0`: Master viewport and canvas background.
  - `Level 1`: Studio docks and persistent side rails.
  - `Level 2`: Active preview cards (4:5 social slide formats) and prompt drawers.
  - `Level 3`: Telemetry inspectors, dropdown filters, and tactical modals.

## Shapes

The design system adopts a strict `roundedness: 0` philosophy. All surfaces, cards, buttons, badges, and modals possess sharp, 90-degree corners. 

This absolute zero-radius execution anchors the athletic broadcast identity, referencing technical monitors, live telemetry bars, sports ticker graphics, and editorial printing blocks. Visual contrast and ergonomic comfort are achieved through disciplined internal padding, razor-sharp hairline framing, and dynamic micro-interactions rather than softened geometry.

## Components

### Buttons & Interactive Triggers
- **Primary CTA (`Exportar` / `Crear publicación`):** Solid `#F4BD44` background with `#0D0B16` high-contrast typography in `Anybody` Bold. Sharp 0px corners, 1px solid border in `#F4BD44`. Hover state applies an intense gold edge glow with a subtle upward translate.
- **Secondary Action (`Generar Copys` / `Variaciones`):** Background `#1F1935`, border 1px solid `#2575FC`, text `#FFFFFF`. Hover triggers an electric blue fill transition (`#2575FC`) with white text.
- **Ghost Utility:** Border 1px solid `#312852`, background transparent, text `#A5A1B8`. Hover illuminates the border to `#7040C8`.

### AI Generation Panels & Prompt Console
- Sleek horizontal command bars docked or floating directly beneath the canvas. 
- Integrated quick-action chips for prompt tonal steering: `Informativo`, `Emocionante`, `Dramático`, `Editorial`, `Viral`. 
- Active chips feature an inverted color block (White on `#2575FC` or Dark on `#F4BD44`) with an uppercase `label-caps` treatment. Inactive chips maintain a dark `#151124` fill with `#312852` borders.

### Sports Content Cards & 4:5 Slide Thumbnails
- Calibrated to the standard 1080x1350 (4:5 portrait) matchday format.
- Structured with high-impact dark layering (`#1F1935`), enclosed by a 1px `#312852` perimeter.
- Selection states activate a continuous 2px `#F4BD44` border ring with gold corner-tick accents.
- Upper card headers house tabular league markers, match timestamps, and score bugs with tabular digits in `stat-counter` styling.

### Input Fields & Controls
- Form fields utilize a `#151124` interior with `#312852` perimeter walls.
- Placeholder text in `#69647C` shifts to `#FFFFFF` on active entry.
- Focus states eliminate default outlines, locking into a 1px `#2575FC` bounding line with a matchday-blue inner hairline.

### Telemetry Sidebar & Navigation Rail
- Minimalist 72px left-side utility column housing modular vertical tool icons (Canvas, AI Text, Templates, Match Feed, Branding).
- Active navigation items display an illuminated left-edge indicator strip in `#2575FC` coupled with high-contrast icon illumination in `#FFFFFF`.